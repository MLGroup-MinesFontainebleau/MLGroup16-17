#include <assert.h>
#include <pthread.h>
#include <stdlib.h>

#define N 1024 * 1024 * 1024
#define N_THREADS 8

float *A, *B, *C;

typedef struct {
  size_t len;
  float *_a;
  float *_b;
  float *_c;
} thread_data;

void *task(void *arg) {
  float *a = ((thread_data *)arg)->_a;
  float *b = ((thread_data *)arg)->_b;
  float *c = ((thread_data *)arg)->_c;

  for (size_t i = 0; i < ((thread_data *)arg)->len; i++)
    c[i] = a[i] + b[i];

  return NULL;
}

int main(void) {
  A = malloc(N * sizeof(float));
  assert(A);
  B = malloc(N * sizeof(float));
  assert(B);
  C = malloc(N * sizeof(float));
  assert(C);

  thread_data data[N_THREADS];

  for (size_t i = 0; i < N_THREADS; i++) {
    data[i].len = N / N_THREADS;
    data[i]._a = &A[i * N / N_THREADS];
    data[i]._b = &B[i * N / N_THREADS];
    data[i]._c = &C[i * N / N_THREADS];
  }

  pthread_t threads[N_THREADS];

  for (size_t i = 0; i < N_THREADS; i++)
    pthread_create(&threads[i], NULL, task, &data[i]);

  for (size_t i = 0; i < N_THREADS; i++)
    pthread_join(threads[i], NULL);

  free(A);
  free(B);
  free(C);
  return 0;
}
