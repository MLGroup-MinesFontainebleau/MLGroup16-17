#include <assert.h>
#include <stdlib.h>

#define N 1024 * 1024 * 1024

float *A, *B, *C;

int main(void) {
  A = malloc(N * sizeof(float));
  assert(A);
  B = malloc(N * sizeof(float));
  assert(B);
  C = malloc(N * sizeof(float));
  assert(C);

  for (size_t i = 0; i < N; i++)
    C[i] = A[i] + B[i];

  free(A);
  free(B);
  free(C);
  return 0;
}
