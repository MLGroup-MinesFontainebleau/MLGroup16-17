#include <assert.h>
#include <pmmintrin.h>
#include <stdlib.h>

#define N 1024 * 1024 * 1024

float *A, *B, *C;

int main(void) {
  A = malloc(N * sizeof(float));
  assert(A);
  B = malloc(N * sizeof(float));
  assert(B);
  C = malloc(N * sizeof(float));
  assert(C);

  __m128 *mm_a = (__m128 *)A;
  __m128 *mm_b = (__m128 *)B;
  __m128 *mm_c = (__m128 *)C;

  for (size_t i = 0; i < N / 4; i++)
    mm_c[i] = _mm_add_ps(mm_a[i], mm_b[i]);

  free(A);
  free(B);
  free(C);
  return 0;
}
