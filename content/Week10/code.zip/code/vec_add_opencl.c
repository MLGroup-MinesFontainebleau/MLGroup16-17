#include <CL/opencl.h>
#include <stdio.h>
#include <stdlib.h>

#define N 1024 * 1024 * 1024
const char *kernel_source = "vec_add.cl";

float *A, *B, *C;

int main(void) {

  // Device input buffers
  cl_mem d_a;
  cl_mem d_b;
  // Device output buffer
  cl_mem d_c;

  cl_platform_id cpPlatform; // OpenCL platform
  cl_device_id device_id;    // device ID
  cl_context ctx;            // context
  cl_command_queue q;        // command queue
  cl_program prgm;           // program
  cl_kernel knl;             // kernel

  // Size, in bytes, of each vector
  size_t n = N;
  size_t bytes = n * sizeof(float);

  // Allocate memory for each vector on host
  A = malloc(bytes);
  B = malloc(bytes);
  C = malloc(bytes);

  size_t globalSize, localSize;
  cl_int err;

  // Number of work items in each local work group
  localSize = 64;

  // Number of total work items - localSize must be devisor
  globalSize = n / localSize * localSize;

  // Bind to platform
  clGetPlatformIDs(1, &cpPlatform, NULL);

  // Get ID for the device
  clGetDeviceIDs(cpPlatform, CL_DEVICE_TYPE_GPU, 1, &device_id, NULL);

  // Create a context
  ctx = clCreateContext(0, 1, &device_id, NULL, NULL, &err);

  // Create a command queue
  q = clCreateCommandQueueWithProperties(ctx, device_id, NULL, &err);

  // Create the compute program from the source buffer
  prgm = clCreateProgramWithSource(ctx, 1, &kernel_source, NULL, &err);

  // Build the program executable
  clBuildProgram(prgm, 0, NULL, NULL, NULL, NULL);

  // Create the compute kernel in the program we wish to run
  knl = clCreateKernel(prgm, "vecAdd", &err);

  // Create the input and output arrays in device memory
  d_a = clCreateBuffer(ctx, CL_MEM_READ_ONLY, bytes, NULL, NULL);
  d_b = clCreateBuffer(ctx, CL_MEM_READ_ONLY, bytes, NULL, NULL);
  d_c = clCreateBuffer(ctx, CL_MEM_WRITE_ONLY, bytes, NULL, NULL);

  // Write our data set into the input array in device memory
  clEnqueueWriteBuffer(q, d_a, CL_TRUE, 0, bytes, A, 0, NULL, NULL);
  clEnqueueWriteBuffer(q, d_b, CL_TRUE, 0, bytes, B, 0, NULL, NULL);

  // Set the arguments to our compute kernel
  clSetKernelArg(knl, 0, sizeof(cl_mem), &d_a);
  clSetKernelArg(knl, 1, sizeof(cl_mem), &d_b);
  clSetKernelArg(knl, 2, sizeof(cl_mem), &d_c);
  clSetKernelArg(knl, 3, sizeof(size_t), &n);

  // Execute the kernel over the entire range of the data set
  clEnqueueNDRangeKernel(q, knl, 1, NULL, &globalSize, &localSize, 0, NULL,
                         NULL);

  // Read the results from the device
  clEnqueueReadBuffer(q, d_c, CL_TRUE, 0, bytes, C, 0, NULL, NULL);

  // Wait for the command queue
  clFinish(q);

  // release OpenCL resources
  clReleaseMemObject(d_a);
  clReleaseMemObject(d_b);
  clReleaseMemObject(d_c);
  clReleaseProgram(prgm);
  clReleaseKernel(knl);
  clReleaseCommandQueue(q);
  clReleaseContext(ctx);

  // release host memory
  free(A);
  free(B);
  free(C);

  return 0;
}
